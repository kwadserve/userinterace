module.exports = {
  name: 'Enlite Prime',
  desc: 'Enlite Prime - React.js Fullstack Template',
  prefix: 'enlite',
  footerText: 'Enlite Prime All Rights Reserved 2018',
  logoText: 'Enlite Prime',
};
