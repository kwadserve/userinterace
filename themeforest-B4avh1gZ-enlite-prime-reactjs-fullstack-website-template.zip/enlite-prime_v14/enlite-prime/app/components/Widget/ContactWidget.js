import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { NavLink } from 'react-router-dom';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Hidden from '@material-ui/core/Hidden';
import Badge from '@material-ui/core/Badge';
import Paper from '@material-ui/core/Paper';
import PhoneIcon from '@material-ui/icons/Phone';
import Chat from '@material-ui/icons/Chat';
import Mail from '@material-ui/icons/Mail';
import NotificationsActive from '@material-ui/icons/NotificationsActive';
import Info from '@material-ui/icons/Info';
import Warning from '@material-ui/icons/Warning';
import Check from '@material-ui/icons/CheckCircle';
import Error from '@material-ui/icons/RemoveCircle';
import AccountBox from '@material-ui/icons/AccountBox';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import PlaylistAddCheck from '@material-ui/icons/PlaylistAddCheck';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import IconButton from '@material-ui/core/IconButton';
import Avatar from '@material-ui/core/Avatar';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import dataContact from 'enl-api/apps/contactData';
import messageStyles from 'enl-styles/Messages.scss';
import { injectIntl, intlShape, FormattedMessage } from 'react-intl';
import messages from './messages';
import styles from './widget-jss';

/* Tab Container */
function TabContainer(props) {
  const { children } = props;
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};
/* END Tab Container */

/* Contact List */
function ContactList(props) {
  const getItem = dataArray => dataArray.map(data => (
    <ListItem
      button
      key={data.id}
    >
      <ListItemAvatar>
        <Avatar alt={data.name} src={data.avatar} className={props.classes.avatar} />
      </ListItemAvatar>
      <ListItemText primary={data.name} secondary={data.title} />
      <Hidden xsDown>
        <ListItemSecondaryAction>
          <Tooltip title={props.intl.formatMessage(messages.chat)}>
            <IconButton className={props.classes.blueText} aria-label="Chat">
              <Chat />
            </IconButton>
          </Tooltip>
          <Tooltip title={props.intl.formatMessage(messages.email)}>
            <IconButton className={props.classes.pinkText} aria-label="Email">
              <Mail />
            </IconButton>
          </Tooltip>
          <Tooltip title={props.intl.formatMessage(messages.call)}>
            <IconButton className={props.classes.tealText} aria-label="Telp">
              <PhoneIcon />
            </IconButton>
          </Tooltip>
        </ListItemSecondaryAction>
      </Hidden>
      <Hidden smUp>
        <ListItemSecondaryAction>
          <IconButton
            aria-label="More"
            aria-haspopup="true"
            onClick={props.openMenu}
          >
            <MoreVertIcon />
          </IconButton>
        </ListItemSecondaryAction>
      </Hidden>
    </ListItem>
  ));
  return (
    <List>
      {getItem(dataContact)}
    </List>
  );
}

ContactList.propTypes = {
  classes: PropTypes.object.isRequired,
  openMenu: PropTypes.func.isRequired,
  intl: intlShape.isRequired
};

const ContactListStyled = withStyles(styles)(injectIntl(ContactList));
/* END Contact List */

/* Conversation List */
function MessagesList(props) {
  const { classes } = props;
  return (
    <List>
      <ListItem button component={NavLink} to="/app/pages/chat">
        <ListItemAvatar>
          <Avatar alt={dataContact[2].name} src={dataContact[2].avatar} className={classes.avatar} />
        </ListItemAvatar>
        <ListItemText primary={dataContact[2].name} className={classes.messages} secondary="Lorem ipsum dolor sit amet, consectetur adipiscing elit." />
        <ListItemSecondaryAction>
          <Typography variant="caption">10:42 PM</Typography>
        </ListItemSecondaryAction>
      </ListItem>
      <ListItem button component={NavLink} to="/app/pages/chat">
        <ListItemAvatar>
          <Avatar alt={dataContact[5].name} src={dataContact[5].avatar} className={classes.avatar} />
        </ListItemAvatar>
        <ListItemText primary={dataContact[5].name} className={classes.messages} secondary="Sed a ipsum euismod, eleifend turpis sed." />
        <ListItemSecondaryAction>
          <Typography variant="caption">11:17 AM</Typography>
        </ListItemSecondaryAction>
      </ListItem>
      <ListItem button component={NavLink} to="/app/pages/chat">
        <ListItemAvatar>
          <Avatar alt={dataContact[1].name} src={dataContact[1].avatar} className={classes.avatar} />
        </ListItemAvatar>
        <ListItemText primary={dataContact[1].name} className={classes.messages} secondary="Praesent viverra est et risus fringilla bibendum." />
        <ListItemSecondaryAction>
          <Typography variant="caption">11 Oct</Typography>
        </ListItemSecondaryAction>
      </ListItem>
      <ListItem button component={NavLink} to="/app/pages/chat">
        <ListItemAvatar>
          <Avatar alt={dataContact[0].name} src={dataContact[0].avatar} className={classes.avatar} />
        </ListItemAvatar>
        <ListItemText primary={dataContact[0].name} className={classes.messages} secondary="Praesent at ex non leo iaculis dignissim. Proin nec venenatis nulla, nec vulputate ipsum. Curabitur eu dignissim nibh, eget condimentum massa." />
        <ListItemSecondaryAction>
          <Typography variant="caption">12 Oct</Typography>
        </ListItemSecondaryAction>
      </ListItem>
    </List>
  );
}

MessagesList.propTypes = {
  classes: PropTypes.object.isRequired,
};

const MessagesListStyled = withStyles(styles)(MessagesList);
/* END Conversation List */

/* Email List */
function NotifList(props) {
  const { classes, openMenu } = props;
  return (
    <List>
      <ListItem button className={messageStyles.messageInfo}>
        <ListItemAvatar>
          <Avatar className={messageStyles.icon}>
            <Info />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Lorem ipsum dolor" secondary="12 Oct 2018" />
        <Hidden xsDown>
          <ListItemSecondaryAction>
            <Button variant="outlined" size="small" color="primary" className={classes.button}>
              <FormattedMessage {...messages.fixit} />
            </Button>
            <Button variant="outlined" size="small" className={classes.button}>
              <FormattedMessage {...messages.skip} />
            </Button>
          </ListItemSecondaryAction>
        </Hidden>
        <Hidden smUp>
          <ListItemSecondaryAction>
            <IconButton
              aria-label="More"
              aria-haspopup="true"
              onClick={openMenu}
            >
              <MoreVertIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </Hidden>
      </ListItem>
      <ListItem button className={messageStyles.messageSuccess}>
        <ListItemAvatar>
          <Avatar className={messageStyles.icon}>
            <Check />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Lorem ipsum dolor" secondary="12 Oct 2018" />
        <Hidden xsDown>
          <ListItemSecondaryAction>
            <Button variant="outlined" size="small" color="primary" className={classes.button}>
              <FormattedMessage {...messages.fixit} />
            </Button>
            <Button variant="outlined" size="small" className={classes.button}>
              <FormattedMessage {...messages.skip} />
            </Button>
          </ListItemSecondaryAction>
        </Hidden>
        <Hidden smUp>
          <ListItemSecondaryAction>
            <IconButton
              aria-label="More"
              aria-haspopup="true"
              onClick={openMenu}
            >
              <MoreVertIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </Hidden>
      </ListItem>
      <ListItem button className={messageStyles.messageWarning}>
        <ListItemAvatar>
          <Avatar className={messageStyles.icon}>
            <Warning />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Lorem ipsum dolor" secondary="12 Oct 2018" />
        <Hidden xsDown>
          <ListItemSecondaryAction>
            <Button variant="outlined" size="small" color="primary" className={classes.button}>
              <FormattedMessage {...messages.fixit} />
            </Button>
            <Button variant="outlined" size="small" className={classes.button}>
              <FormattedMessage {...messages.skip} />
            </Button>
          </ListItemSecondaryAction>
        </Hidden>
        <Hidden smUp>
          <ListItemSecondaryAction>
            <IconButton
              aria-label="More"
              aria-haspopup="true"
              onClick={openMenu}
            >
              <MoreVertIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </Hidden>
      </ListItem>
      <ListItem button className={messageStyles.messageError}>
        <ListItemAvatar>
          <Avatar className={messageStyles.icon}>
            <Error />
          </Avatar>
        </ListItemAvatar>
        <ListItemText primary="Lorem ipsum dolor" secondary="12 Oct 2018" />
        <Hidden xsDown>
          <ListItemSecondaryAction>
            <Button variant="outlined" size="small" color="primary" className={classes.button}>
              <FormattedMessage {...messages.fixit} />
            </Button>
            <Button variant="outlined" size="small" className={classes.button}>
              <FormattedMessage {...messages.skip} />
            </Button>
          </ListItemSecondaryAction>
        </Hidden>
        <Hidden smUp>
          <ListItemSecondaryAction>
            <IconButton
              aria-label="More"
              aria-haspopup="true"
              onClick={openMenu}
            >
              <MoreVertIcon />
            </IconButton>
          </ListItemSecondaryAction>
        </Hidden>
      </ListItem>
    </List>
  );
}

NotifList.propTypes = {
  classes: PropTypes.object.isRequired,
  openMenu: PropTypes.func.isRequired,
};

const NotifListStyled = withStyles(styles)(injectIntl(NotifList));
/* END Email List */

class ContactWidget extends React.Component {
  state = {
    value: 0,
    anchorEl: null,
    anchorElAction: null,
  };

  handleChange = (event, value) => {
    this.setState({ value });
  };

  handleOpen = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleOpenAction = event => {
    this.setState({ anchorElAction: event.currentTarget });
  };

  handleClose = () => {
    this.setState({
      anchorEl: null,
      anchorElAction: null
    });
  };

  render() {
    const { classes, intl } = this.props;
    const { value, anchorEl, anchorElAction } = this.state;
    const open = Boolean(anchorEl);
    const openAct = Boolean(anchorElAction);
    return (
      <Fragment>
        <Menu
          id="long-menu"
          anchorEl={anchorEl}
          open={open}
          onClose={this.handleClose}
        >
          <MenuItem onClick={this.handleClose}>
            <ListItemIcon>
              <Chat className={classes.blueText} />
            </ListItemIcon>
            <ListItemText variant="inset" primary="Chat" />
          </MenuItem>
          <MenuItem onClick={this.handleClose}>
            <ListItemIcon>
              <Mail className={classes.pinkText} />
            </ListItemIcon>
            <ListItemText variant="inset" primary="Email" />
          </MenuItem>
          <MenuItem onClick={this.handleClose}>
            <ListItemIcon>
              <PhoneIcon className={classes.tealText} />
            </ListItemIcon>
            <ListItemText variant="inset" primary="Call" />
          </MenuItem>
        </Menu>
        <Menu
          id="long-menu-act"
          anchorEl={anchorElAction}
          open={openAct}
          onClose={this.handleClose}
        >
          <MenuItem onClick={this.handleClose}>
            <ListItemIcon>
              <Check className={classes.tealText} />
            </ListItemIcon>
            <ListItemText variant="inset" primary="Fix it" />
          </MenuItem>
          <MenuItem onClick={this.handleClose}>
            <ListItemIcon>
              <PlaylistAddCheck />
            </ListItemIcon>
            <ListItemText variant="inset" primary="Skip" />
          </MenuItem>
        </Menu>
        <Paper className={classes.rootContact}>
          <AppBar position="static" color="default">
            <Hidden mdUp>
              <Tabs
                value={value}
                onChange={this.handleChange}
                indicatorColor="primary"
                textColor="primary"
                variant="fullWidth"
              >
                <Tab icon={<AccountBox />} />
                <Tab icon={<Chat />} />
                <Tab icon={<NotificationsActive />} />
              </Tabs>
            </Hidden>
            <Hidden smDown>
              <Tabs
                value={value}
                onChange={this.handleChange}
                indicatorColor="primary"
                textColor="primary"
                variant="fullWidth"
              >
                <Tab label={intl.formatMessage(messages.contacts)} icon={<AccountBox />} />
                <Tab
                  label={(
                    <Badge className={classes.tabNotif} color="secondary" badgeContent={4}>
                      <FormattedMessage {...messages.massages} />
                    </Badge>
                  )}
                  icon={<Chat />}
                />
                <Tab
                  label={(
                    <Badge className={classes.tabNotif} color="secondary" badgeContent={4}>
                      <FormattedMessage {...messages.notification} />
                    </Badge>
                  )}
                  icon={<NotificationsActive />}
                />
              </Tabs>
            </Hidden>
          </AppBar>
          {value === 0 && <TabContainer><ContactListStyled openMenu={this.handleOpen} /></TabContainer>}
          {value === 1 && <TabContainer><MessagesListStyled /></TabContainer>}
          {value === 2 && <TabContainer><NotifListStyled openMenu={this.handleOpenAction} /></TabContainer>}
        </Paper>
      </Fragment>
    );
  }
}

ContactWidget.propTypes = {
  classes: PropTypes.object.isRequired,
  intl: intlShape.isRequired
};

export default withStyles(styles)(injectIntl(ContactWidget));
