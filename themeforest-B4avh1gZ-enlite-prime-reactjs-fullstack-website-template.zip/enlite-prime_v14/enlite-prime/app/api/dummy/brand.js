module.exports = {
  name: 'Enlite Prime',
  desc: 'Enlite Prime - React.js Fullstack Template',
  prefix: 'enlite',
  footerText: 'Enlite Prime All Rights Reserved 2019',
  logoText: 'Enlite Prime',
};
